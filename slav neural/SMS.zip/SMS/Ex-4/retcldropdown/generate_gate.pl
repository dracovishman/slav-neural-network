#!/usr/bin/perl
use strict;
use warnings;

# Check if the correct number of arguments is passed
if (@ARGV != 5) {
    die "Usage: generate_gate.pl <gate_name> <module_name> <input1> <input2> <output>\n";
}

# Extract command-line arguments
my ($gate_name, $module, $a, $b, $c) = @ARGV;

# Remove any trailing newline characters
chomp($module, $a, $b, $c);

# Open the Verilog file for writing
open(my $vlog, ">", "$module.v") or die "Could not open file '$module.v' for writing: $!\n";

# Print the module declaration
print $vlog "module $module($c, $b, $a);\n";
print $vlog "input $a, $b;\n";
print $vlog "output $c;\n";

# Generate the Verilog code based on the gate type
if ($gate_name eq 'and') {
    print $vlog "assign $c = $a & $b;\n";
} elsif ($gate_name eq 'or') {
    print $vlog "assign $c = $a | $b;\n";
} elsif ($gate_name eq 'nor') {
    print $vlog "assign $c = ~($a | $b);\n";
} elsif ($gate_name eq 'nand') {
    print $vlog "assign $c = ~($a & $b);\n";
} elsif ($gate_name eq 'xor') {
    print $vlog "assign $c = $a ^ $b;\n";
} elsif ($gate_name eq 'xnor') {
    print $vlog "assign $c = ~($a ^ $b);\n";
} else {
    die "Invalid gate name: $gate_name. Please select a valid gate.\n";
}

# Close the Verilog file
print $vlog "endmodule\n";
close $vlog;

print "Verilog code for $gate_name gate written to '$module.v'.\n";