use strict;
use warnings;

# Open the report file for writing
open(my $report_fh, '>', 'log_analysis_report.txt') or die "Cannot open report file: $!";

# Print header for the report
print $report_fh "=" x 80 . "\n";
print $report_fh "LOG FILE ANALYSIS REPORT\n";
print $report_fh "=" x 80 . "\n\n";

# Print header for terminal output
print "=" x 80 . "\n";
print "LOG FILE ANALYSIS\n";
print "=" x 80 . "\n";

# Define the log files in the current directory (only .log files)
my @log_files = glob("*.log");  # This will get all .log files in the current directory

# Ensure that at least two log files are found
if (scalar @log_files < 2) {
    die "Error: Expected at least two .log files in the directory, found " . scalar(@log_files) . ".\n";
}

# Subroutine to process each log file and generate output
sub process_log_file {
    my ($file) = @_;
    
    # Print file header to terminal and report
    print "\n" . "-" x 80 . "\n";
    print "Processing file: $file\n";
    print "-" x 80 . "\n";
    print $report_fh "Processing file: $file\n";
    print $report_fh "-" x 80 . "\n";

    open(my $fh, '<', $file) or die "Cannot open file $file: $!";
    
    my ($test_name, $status, $error_message);
    
    # Read the log file line by line
    while (my $line = <$fh>) {
        chomp($line);
        
        # Debugging: print the line to check if it matches
        print "Processing line: $line\n";  # Debugging line

        # Capture the test name from the line
        if ($line =~ /Test Name:\s*(\S+)/) {
            $test_name = $1;
        }
        
        # Capture the test status (SUCCESS or FAILURE)
        if ($line =~ /Test Status:\s*(SUCCESS|FAILURE)/) {
            $status = $1 eq 'SUCCESS' ? 'TEST PASSED' : 'TEST FAILED';
        }
        
        # Capture the error message if present (optional)
        if ($line =~ /Error:\s*(.*)/) {
            $error_message = $1;
        }
    }

    close($fh);

    # Default values in case no data was found
    $test_name = $test_name // 'Unknown';
    $status = $status // 'Unknown';
    $error_message = $error_message // 'N/A';

    # Print the results to the terminal
    print "Test Name: $test_name\n";
    print "Status: $status\n";
    print "Error Message: $error_message\n";

    # Write results to the report file
    print $report_fh "Test Name: $test_name\n";
    print $report_fh "Status: $status\n";
    print $report_fh "Error Message: $error_message\n";
    print $report_fh "\n";
}

# Process both log files
foreach my $file (@log_files) {
    process_log_file($file);
}

# Print footer for terminal output
print "=" x 80 . "\n";
print "End of log analysis\n";
print "=" x 80 . "\n";

# Print footer for report file
print $report_fh "=" x 80 . "\n";
print $report_fh "End of log analysis\n";
print $report_fh "=" x 80 . "\n";

# Close the report file
close($report_fh);

print "Log analysis complete. Report generated in 'log_analysis_report.txt'.\n";