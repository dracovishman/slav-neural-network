#!/usr/bin/perl
use strict;
use warnings;

# Hash to store contacts
my %contacts;

# Menu options stored in an array
my @menu_options = (
    "Add a Contact",
    "Display All Contacts",
    "Exit"
);

# Subroutine to add a new contact
sub add_contact {
    print "Enter contact name: ";
    chomp(my $name = <STDIN>);

    print "Enter phone number: ";
    chomp(my $phone = <STDIN>);

    if ($name && $phone) {
        $contacts{$name} = $phone;
        print "\nContact added successfully!\n\n";
    } else {
        print "\nInvalid input. Please provide both name and phone number.\n\n";
    }
}

# Subroutine to display all contacts
sub display_contacts {
    print "\nContacts:\n";
    if (keys %contacts) {
        foreach my $name (sort keys %contacts) {
            print "$name - $contacts{$name}\n";
        }
    } else {
        print "No contacts found.\n";
    }
    print "\n";
}

# Main program loop
while (1) {
    print "Welcome to the Contact Management System!\n";
    for my $i (0 .. $#menu_options) {
        print $i + 1, ". $menu_options[$i]\n";
    }

    print "\nEnter your choice: ";
    chomp(my $choice = <STDIN>);

    if ($choice == 1) {
        add_contact();
    } elsif ($choice == 2) {
        display_contacts();
    } elsif ($choice == 3) {
        print "\nGoodbye_exit!\n";
        last;
    } else {
        print "\nInvalid choice. Please try again.\n\n";
    }
}