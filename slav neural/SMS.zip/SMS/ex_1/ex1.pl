# 1. Scalar Data
# Question: Write a script to store and display a user's age using a scalar variable.

#!/usr/bin/perl
use strict;
use warnings;

# Store age in a scalar variable
my $age = 25;
print "The user's age is: $age\n";



# 2. Lists and Arrays
# Question: Write a script to store a list of fruits in an array and display them.

# Store fruits in an array
my @fruits = ("Apple", "Banana", "Cherry");

# Display the fruits
print "Fruits: \n";
foreach my $fruit (@fruits) {
    print "$fruit\n";
}

# ---

# 3. Control Structures
# Question: Write a script to check if a number is even or odd.


# Input number
print "Enter a number: ";
chomp(my $number = <STDIN>);

# Check if the number is even or odd
if ($number % 2 == 0) {
    print "$number is even.\n";
} else {
    print "$number is odd.\n";
}

# ---

# 4. Subroutines
# Question: Write a script with a subroutine that takes two numbers and returns their sum.


# Subroutine to calculate sum
sub calculate_sum {
    my ($num1, $num2) = @_;
    return $num1 + $num2;
}

# Input numbers
print "Enter first number: ";
chomp(my $num1 = <STDIN>);
print "Enter second number: ";
chomp(my $num2 = <STDIN>);

# Call subroutine and display result
my $sum = calculate_sum($num1, $num2);
print "The sum is: $sum\n";

# ---

# 5. Input and Output
# Question: Write a script to take a user's name as input and display a greeting message.


# Input user's name
print "Enter your name: ";
chomp(my $name = <STDIN>);

# Display greeting
print "Hello, $name! Welcome to Perl programming.\n";

# ---

# 6. Hashes
# Question: Write a script to store and display employee details (name and age) using a hash.


# Store employee details in a hash
my %employee = (
    "Alice" => 30,
    "Bob"   => 25,
    "Charlie" => 35,
);

# Display employee details
print "Employee Details:\n";
foreach my $name (keys %employee) {
    print "$name is $employee{$name} years old.\n";
}