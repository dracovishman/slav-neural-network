# File Operations in Perl

# 1. Create and Write to a File
# Question: Write a script to create a file, write some text into it, and then close the file.

#!/usr/bin/perl
use strict;
use warnings;

# Create and write to a file
my $filename = "create_and_write.txt";
open(my $fh, '>', $filename) or die "Could not create file '$filename' $!";
print $fh "This is a newly created file with some content.\n";
close($fh);
print "File '$filename' created and written successfully.\n";

# ---

# 2. Read from a File
# Question: Write a script to read and display the contents of a file.

#!/usr/bin/perl
use strict;
use warnings;

# Read from a file
my $read_file = "read_example.txt";
open(my $rfh, '<', $read_file) or die "Could not open file '$read_file' $!";

while (my $line = <$rfh>) {
    print $line;  # Print each line from the file
}

close($rfh);
print "\nFile '$read_file' read successfully.\n";

# ---

# 3. Append to a File
# Question: Write a script to append text to an existing file.

#!/usr/bin/perl
use strict;
use warnings;

# Append to a file
my $append_file = "append_example.txt";
open(my $afh, '>>', $append_file) or die "Could not open file '$append_file' $!";

print $afh "Appending new content to the file.\n";
print $afh "This is another line of appended text.\n";

close($afh);
print "Data appended to file '$append_file' successfully.\n";

# ---

# 4. Check if File Exists and Open Safely
# Question: Write a script to check if a file exists before opening it.

#!/usr/bin/perl
use strict;
use warnings;

# Check and read a file
my $check_file = "check_example.txt";
if (-e $check_file) {
    open(my $cfh, '<', $check_file) or die "Could not open file '$check_file' $!";
    while (my $line = <$cfh>) {
        print $line;
    }
    close($cfh);
} else {
    print "File '$check_file' does not exist.\n";
}

# ---

# 5. Read and Write Simultaneously
# Question: Write a script to read from a file and write its content to another file.

#!/usr/bin/perl
use strict;
use warnings;

# Read from one file and write to another
my $input_file = "input_example.txt";
my $output_file = "output_example.txt";

open(my $in_fh, '<', $input_file) or die "Could not open file '$input_file' $!";
open(my $out_fh, '>', $output_file) or die "Could not create file '$output_file' $!";

while (my $line = <$in_fh>) {
    print $out_fh $line;  # Write each line to the output file
}

close($in_fh);
close($out_fh);
print "Contents of '$input_file' copied to '$output_file' successfully.\n";