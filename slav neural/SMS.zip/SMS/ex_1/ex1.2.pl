#!/usr/bin/perl
use strict;
use warnings;

# File to store contacts
my $contact_file = 'contacts.txt';

# Hash to store contacts
my %contacts;

# Subroutine to load contacts from a file
sub load_contacts {
    if (-e $contact_file) {
        open my $fh, '<', $contact_file or die "Could not open file '$contact_file': $!";
        while (my $line = <$fh>) {
            chomp $line;
            my ($name, $phone) = split /,/, $line, 2;
            $contacts{$name} = $phone;
        }
        close $fh;
    }
}

# Subroutine to save contacts to a file
sub save_contacts {
    open my $fh, '>', $contact_file or die "Could not open file '$contact_file': $!";
    foreach my $name (sort keys %contacts) {
        print $fh "$name,$contacts{$name}\n";
    }
    close $fh;
}

# Subroutine to add a new contact
sub add_contact {
    print "Enter contact name: ";
    chomp(my $name = <STDIN>);

    print "Enter phone number: ";
    chomp(my $phone = <STDIN>);

    if ($name && $phone) {
        if (exists $contacts{$name}) {
            print "Contact already exists. Overwrite? (y/n): ";
            chomp(my $overwrite = <STDIN>);
            if (lc($overwrite) eq 'y') {
                $contacts{$name} = $phone;
                print "\nContact updated successfully!\n\n";
            } else {
                print "\nContact not updated.\n\n";
            }
        } else {
            $contacts{$name} = $phone;
            print "\nContact added successfully!\n\n";
        }
    } else {
        print "\nInvalid input. Please provide both name and phone number.\n\n";
    }

    save_contacts();
}

# Subroutine to display all contacts
sub display_contacts {
    print "\nContacts:\n";
    if (keys %contacts) {
        foreach my $name (sort keys %contacts) {
            print "$name - $contacts{$name}\n";
        }
    } else {
        print "No contacts found.\n";
    }
    print "\n";
}

# Load contacts from file at the start
load_contacts();

# Menu options stored in an array
my @menu_options = (
    "Add a Contact",
    "Display All Contacts",
    "Exit"
);

# Main program loop
while (1) {
    print "Welcome to the Contact Management System!\n";
    for my $i (0 .. $#menu_options) {
        print $i + 1, ". $menu_options[$i]\n";
    }

    print "\nEnter your choice: ";
    chomp(my $choice = <STDIN>);

    if ($choice == 1) {
        add_contact();
    } elsif ($choice == 2) {
        display_contacts();
    } elsif ($choice == 3) {
        print "\nGoodbye!\n";
        last;
    } else {
        print "\nInvalid choice. Please try again.\n\n";
    }
}